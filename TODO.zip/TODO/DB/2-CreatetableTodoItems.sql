



CREATE TABLE TodoItems (
    Id BIGINT PRIMARY KEY,
    Title NVARCHAR(MAX),
    Description NVARCHAR(MAX),
    IsCompleted BIT
);


