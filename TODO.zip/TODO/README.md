## You have to installed Microsoft.Data.SqlClient package
## also in this i have used swagger for testing